

int main()
{
  bar(20);
  bar(50);
  foo();
  return 0;
}