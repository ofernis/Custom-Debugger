
int main()
{
  for(int i = 0; i < 42; i++)
  {
     foo(i);
  }
  return 0;
}