
int main()
{
  rec_foo();
  return 0;
}