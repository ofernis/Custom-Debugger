
int main()
{
  bar(42);
  bar(6);
  bar(9);
  foo();
  return 0;
}