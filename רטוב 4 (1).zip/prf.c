#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <signal.h>
#include <syscall.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/reg.h>
#include <sys/user.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <errno.h>
#include <fcntl.h>
#include "elf64.h"
#include "symbol.h"

void run_sys_debugger(pid_t child_pid, unsigned long func_addr) {
    int wait_status;
    struct user_regs_struct regs; 
    waitpid(child_pid, &wait_status, 0);

    //breakpoint at caller to the debugged function
    unsigned long data = ptrace(PTRACE_PEEKTEXT, child_pid, (void*)func_addr, NULL);
    unsigned long data_trap = (data & 0xFFFFFFFFFFFFFF00) | 0xCC;
    ptrace(PTRACE_POKETEXT, child_pid, (void*)func_addr, (void*)data_trap);
    
    ptrace(PTRACE_CONT, child_pid, NULL, NULL);
    wait(&wait_status);
    bool inside_func = true;
    
    while(WIFSTOPPED(wait_status)) {
        ptrace(PTRACE_GETREGS, child_pid, 0, &regs);
        if (regs.rip - 1 == func_addr) {
            ptrace(PTRACE_GETREGS, child_pid, NULL, &regs);
            unsigned long rsp = regs.rsp; 

            ptrace(PTRACE_POKETEXT, child_pid, (void*)func_addr, (void*)data);

            Elf64_Addr return_address = ptrace(PTRACE_PEEKTEXT, child_pid, rsp, NULL);
            unsigned long return_data = ptrace(PTRACE_PEEKTEXT, child_pid, return_address, NULL);
            unsigned long return_data_trap = (return_data & 0xFFFFFFFFFFFFFF00) | 0xCC;
            ptrace(PTRACE_POKETEXT, child_pid, return_address, (void*)return_data_trap);

            ptrace(PTRACE_GETREGS, child_pid, 0, &regs);
            regs.rip -= 1;
            ptrace(PTRACE_SETREGS, child_pid, 0, &regs);

            while(!WIFEXITED(wait_status) && inside_func) {
                ptrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
                wait(&wait_status);
                
                ptrace(PTRACE_GETREGS, child_pid, 0, &regs);

                if(regs.rip != return_address + 1) {
                    unsigned long long syscall_address = regs.rip - 2;
                    ptrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
                    wait(&wait_status);
                    ptrace(PTRACE_GETREGS, child_pid, 0, &regs);

                    if((int)(regs.rax) < 0 && inside_func){
                        printf("PRF:: the syscall in 0x%llx returned with %lld\n" ,syscall_address, regs.rax);
                    }
                }
                else {
                    ptrace(PTRACE_POKETEXT, child_pid, (void*)return_address, (void*)return_data);

                    ptrace(PTRACE_GETREGS, child_pid, 0, &regs);
                    regs.rip -= 1;
                    ptrace(PTRACE_SETREGS, child_pid, 0, &regs);       
                              
                    ptrace(PTRACE_POKETEXT, child_pid, (void*)func_addr, (void*)data_trap);
                    inside_func = false;
                    ptrace(PTRACE_CONT, child_pid, NULL, NULL);
                    
                    wait(&wait_status);

                    ptrace(PTRACE_GETREGS, child_pid, 0, &regs);
                    if (regs.rip - 1 == func_addr){
                        inside_func = true;
                        break;
                    }
                    else {
                        ptrace(PTRACE_CONT, child_pid, NULL, NULL);
                    }
                }

            }
            
        }
        ptrace(PTRACE_GETREGS, child_pid, 0, &regs);
        if (regs.rip - 1 == func_addr){
            continue;
        }
        inside_func = false;
        wait(&wait_status);
        if (WIFEXITED(wait_status))
            break;
        
    }
}

pid_t run_target(const char* func, char** argv){
    pid_t pid = fork();

    if(pid > 0){
        return pid;
    } else if (pid == 0) {
        if (ptrace(PTRACE_TRACEME, 0, NULL, NULL) < 0) {
			perror("ptrace");
			exit(1);
        }
		execl(func, *(argv + 2), NULL);

	} else {
		perror("fork");
        exit(1);
    }
}

int main(int argc, char** argv){
    unsigned int sym_count = 0;
    char* func_name = argv[1];
    char* exefile_name = argv[2];
    unsigned long symbol_addr = find_symbol(func_name, exefile_name, &sym_count);
    if(symbol_addr == -3){
        printf("PRF:: %s not an executable!\n", func_name);
        return 0;
    } 
    else if(symbol_addr == -1){
        printf("PRF:: %s not found!\n", func_name);
        return 0;
    }
    else if (symbol_addr == -2) {
        printf("PRF:: %s is a local symbol %d times!\n", func_name, sym_count);
        return 0;
    }

    pid_t child_pid = run_target(exefile_name, argv);
    run_sys_debugger(child_pid, symbol_addr);
    return 0;
}