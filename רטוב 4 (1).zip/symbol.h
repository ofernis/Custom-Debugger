#ifndef SYMBOL_H
#define SYMBOL_H

long find_symbol(char* symbol_name, char* exe_file_name, unsigned int* local_count);

#endif /* SYMBOL_H */